<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PlayerTeamsController extends Controller
{
    //
}
