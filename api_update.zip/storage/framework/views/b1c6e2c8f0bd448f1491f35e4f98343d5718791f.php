<?php
use App\Hero;
use App\User;
use App\Auth;
    $selectedBattlerites = explode(', ', $build->build, 6);
    if($build->user_id != 0) {
        $user = User::where('id', $build->user_id)->firstOrFail();
        $username = $user->name;
    } else {
        $username = 'Anonymous';
    }
    $description = $hero->name. ' build for battlerite. Learn the optimal way to play '.$hero->name.' to climb the leaderboards and improve your ranking.';

?>


<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('description', $description); ?>
<?php $__env->startSection('content'); ?>

<div class="content-block">
    <div class="build-header">
        <img src="<?php echo e(asset('images/'.$hero->name.'/icon.png')); ?>" class="hero-img" alt="<?php echo e($hero->name); ?>">
        <div class="build-title">
            <h1 class="page-title"><?php echo e($build->title); ?></h1>
            <h2>Build by <?php echo e($username); ?> on <?php echo e(date("m-d-Y", strtotime($build->created_at))); ?></h2>
            <h3>Score: <span class="score"><?php echo e($build->score); ?></span></h3>
        </div>
        <div class="rate">
            <div class="buttons">
                <span class="upvote" onclick="rate('<?php echo e($build->id); ?>', 'up')">Upvote</span> <br/>
                <span class="downvote" onclick="rate('<?php echo e($build->id); ?>', 'down')">Downvote</span>
            </div>
        </div>
    </div>
        <!-- SELECTED BATTLERITES -->
        <?php if(count($selectedBattlerites) > 0): ?>
            <?php if(count($hero->battlerites) > 0): ?>
                <div class="build-row view">
                <?php $__currentLoopData = $selectedBattlerites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selectedBattlerite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $hero->battlerites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $battlerite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($selectedBattlerite == $battlerite->name): ?>
                        <div class="build battlerites text-center">
                            <div class="build-img text-center">
                                <img src="<?php echo e(asset('images/'.$hero->name.'/abilities/'.$battlerite->hotkey.'.png')); ?>" class="skill-img <?php echo e(strtolower($battlerite->category)); ?>" alt="<?php echo e($hero->name); ?> Battlerite - <?php echo e($battlerite->name); ?>">
                            </div>
                            
                            <p><?php echo e($battlerite->name); ?></p>
                            <div class="tooltip text-center">
                                <h3><?php echo e($battlerite->name); ?></h3>
                                <p><?php echo e($battlerite->description); ?></p>
                            </div>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                </table>
            <?php endif; ?>
        <?php endif; ?>
        <!-- END SELECTED BATTLERITES -->
        <div class="build body">
            <h2>Author Advice</h2>
            <?php echo $build->body; ?>

        </div>
        <!-- ABILITIES
        <?php if(count($hero->abilities) > 0): ?>
            <table>
                <tr>
                    <th>Hotkey</th>
                    <th>Name</th>
                    <th>Description</th>
                </tr>
                <?php $__currentLoopData = $hero->abilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ability): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($ability->hotkey); ?></td>
                        <td><?php echo e($ability->name); ?></td>
                        <td><?php echo e($ability->description); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        <?php endif; ?>
        <!-- END ABILITIES -->
        </div>

        
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>