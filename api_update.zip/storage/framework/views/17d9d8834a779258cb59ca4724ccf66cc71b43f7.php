<?php 
use App\Hero;
use App\User;
use App\Auth;
use App\Build;
use App\Post;
$posts = Post::orderBy('created_at', 'desc')->paginate(5);
$heroes = Hero::all();
$recentBuilds = Build::orderBy('created_at', 'desc')->paginate(3);
$popularBuilds = Build::orderBy('views', 'desc')->paginate(3);
?>



<?php $__env->startSection('title', 'For all your Battlerite needs'); ?>

<?php $__env->startSection('content'); ?>
<div class="hero content-block">
        <h3 class="bold primary-color mb-10">Find Builds</h3>
        <?php $__currentLoopData = $heroes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <div class="hero-img">
                        <a href="/builds/<?php echo e($hero->name); ?>"><img src="<?php echo e(asset('images/'.$hero->name.'/icon.png')); ?>"></a>
                </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
</div>
<div class="row index">
        <div class="col-lg-6">
                <div class="builds-row content-block">
                        <h3 class="bold primary-color mb-10">Popular Builds</h3>
                        <div class="builds-box">
                                <?php $__currentLoopData = $popularBuilds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $build): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $selectedBattlerites = explode(', ', $build->build, 5);
                                                $hero = Hero::where('id', $build->hero_id)->firstOrFail();
                                                if($build->user_id != 0) {
                                                $user = User::where('id', $build->user_id)->firstOrFail();
                                                $username = $user->name;
                                                } else {
                                                $username = 'Anonymous';
                                                }
                                        ?>
                                        <div class="build-row">
                                                <div class="build-content">
                                                        <div class="build-image">
                                                                <a href="/builds/view/<?php echo e($build->id); ?>-<?php echo e($build->slug); ?>">
                                                                <img src="<?php echo e(asset('images/'.$hero->name.'/icon.png')); ?>">
                                                                </a>
                                                        </div>
                                                        <div class="build-desc">
                                                        <h3><a href="/builds/view/<?php echo e($build->id); ?>-<?php echo e($build->slug); ?>"><?php echo e($build->title); ?></a></h3>
                                                        <small>Build by <?php echo e($username); ?> on <?php echo e(date("m-d-Y", strtotime($build->created_at))); ?></small>
                                                        <small><?php if($build->featured == 1) { echo '<span class="primary">FEATURED</span> | '; } ?>Views: <?php echo e($build->views); ?> | Score <?php echo e($build->score); ?></small>
                                                        </div>
                                                </div>
                                        </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                </div>
        </div>
        <div class="col-lg-6">
                <div class="content-block builds-row">
                        <h3 class="bold primary-color mb-10">Recent Builds</h3>
                        <div class="builds-box">
                                <?php $__currentLoopData = $recentBuilds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $build): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $selectedBattlerites = explode(', ', $build->build, 5);
                                        $hero = Hero::where('id', $build->hero_id)->firstOrFail();
                                        if($build->user_id != 0) {
                                                $user = User::where('id', $build->user_id)->firstOrFail();
                                                $username = $user->name;
                                        } else {
                                                $username = 'Anonymous';
                                        }
                                        ?>
                                        <div class="build-row">
                                                <div class="build-content">
                                                        <div class="build-image">
                                                                <a href="/builds/view/<?php echo e($build->id); ?>-<?php echo e($build->slug); ?>">
                                                                <img src="<?php echo e(asset('images/'.$hero->name.'/icon.png')); ?>">
                                                                </a>
                                                        </div>
                                                        <div class="build-desc">
                                                        <h3><a href="/builds/view/<?php echo e($build->id); ?>-<?php echo e($build->slug); ?>"><?php echo e($build->title); ?></a></h3>
                                                        <small>Build by <?php echo e($username); ?> on <?php echo e(date("m-d-Y", strtotime($build->created_at))); ?></small>
                                                        <small><?php if($build->featured == 1) { echo '<span class="primary">FEATURED</span> | '; } ?>Views: <?php echo e($build->views); ?> | Score <?php echo e($build->score); ?></small>
                                                        </div>
                                                </div>
                                        </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                </div>
        </div>
</div>
<div class="row">
        <div class="col-xs-12">
                <?php if(count($posts) > 0): ?> 
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="well post">
                                <h3 class="bold"><a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></h3>
                                <p><?php echo $post->body; ?></p>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                        <p>No Posts Found</p>
                <?php endif; ?>
        </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>