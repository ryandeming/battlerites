<?php 

use App\Hero;
use App\Player;
use App\PlayerStat;
use App\PlayerTeam;
use App\PlayerMatch;

?>

<?php if($title): ?>
    <?php $__env->startSection('title', $title); ?>
<?php endif; ?>
<?php $__env->startSection('content'); ?>       
<div class="row match-row">
    <div class="col-md-6">
        <div class="content-block">
            <h2>Winning Team</h2>
            <div class="match-history">
                <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($player->result == 'true'): ?>
                        <?php 
                        $playerName = Player::where('id', $player->player_id)->first(); 
                        //$playerName = new Player;
                        //$playerName->username = "abc";?>
                    <div class="match">
                        <img src="<?php echo e(asset('images/'.$player->hero_name.'/icon.png')); ?>" class="hero-img" alt="<?php echo e($player->hero_name); ?>">
                        <p class="match-type"><?php echo e($player->type); ?></p>
                        <p class="result win"><?php echo e($playerName->username); ?></p>
                        <p>as <?php echo e($player->hero_name); ?></p>
                        <p class="time"><?php echo e(date("m-d-Y", strtotime($player->date))); ?></p>
                        <a href="/player/<?php echo e($playerName->username); ?>" class="expand">View player page</a>
                        <div class="match-stats-box" style="clear:both;">
                            <p>Damage Done: <span class="bold lightgreen"><?php echo e($player->damage_done); ?></span> <span class="right">Damage Received: <span class="bold orangered"><?php echo e($player->damage_received); ?></span></span></p>
                            <p>Healing Done: <span class="bold lightgreen"><?php echo e($player->healing_done); ?></span> <span class="right">Healing Received: <span class="bold orangered"><?php echo e($player->healing_received); ?></span></span></p>
                            <p>Disables Done: <span class="bold lightgreen"><?php echo e($player->disables_done); ?></span> <span class="right">Disables Received: <span class="bold orangered"><?php echo e($player->disables_received); ?></span></span></p>
                            <p>Kills: <span class="bold lightgreen"><?php echo e($player->kills); ?></span> <span class="right">Deaths: <span class="bold orangered"><?php echo e($player->deaths); ?></span></span></p>
                            <p class="score bold text-center">Total Score: <span class="lightgreen"><?php echo e($player->score); ?></span></p>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="content-block">
            <h2>Losing Team</h2>
            <div class="match-history">
                <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($player->result == 'false'): ?>
                        <?php 
                        $playerName = Player::where('id', $player->player_id)->first(); 
                        ?>
                    <div class="match">
                        <img src="<?php echo e(asset('images/'.$player->hero_name.'/icon.png')); ?>" class="hero-img" alt="<?php echo e($player->hero_name); ?>">
                        <p class="match-type"><?php echo e($player->type); ?></p>
                        <p class="result loss"><?php echo e($playerName->username); ?></p>
                        <p>as <?php echo e($player->hero_name); ?></p>
                        <p class="time"><?php echo e(date("m-d-Y", strtotime($player->date))); ?></p>
                        <a href="/player/<?php echo e($playerName->username); ?>" class="expand">View player page</a>
                        <div class="match-stats-box" style="clear:both;">
                            <p>Damage Done: <span class="bold lightgreen"><?php echo e($player->damage_done); ?></span> <span class="right">Damage Received: <span class="bold orangered"><?php echo e($player->damage_received); ?></span></span></p>
                            <p>Healing Done: <span class="bold lightgreen"><?php echo e($player->healing_done); ?></span> <span class="right">Healing Received: <span class="bold orangered"><?php echo e($player->healing_received); ?></span></span></p>
                            <p>Disables Done: <span class="bold lightgreen"><?php echo e($player->disables_done); ?></span> <span class="right">Disables Received: <span class="bold orangered"><?php echo e($player->disables_received); ?></span></span></p>
                            <p>Kills: <span class="bold lightgreen"><?php echo e($player->kills); ?></span> <span class="right">Deaths: <span class="bold orangered"><?php echo e($player->deaths); ?></span></span></p>
                            <p class="score bold text-center">Total Score: <span class="orangered"><?php echo e($player->score); ?></span></p>
                        </div>
                    </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>