@extends('layouts.app')

@section('content')
        <h1>About</h1>
        <p>Who gives a shit</p>
@endsection
