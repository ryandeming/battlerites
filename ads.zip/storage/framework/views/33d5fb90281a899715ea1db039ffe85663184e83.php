<?php $__env->startSection('content'); ?>
<div class="builds-container">
        <?php if(count($heroes) > 0): ?>
        <div class="content-block">
                <h1 class="page-title">Select Hero</h1>
                <?php $__currentLoopData = $heroes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                        <div class="hero-img">
                        <a href="create/<?php echo e($hero->name); ?>"><img src="<?php echo e(asset('images/'.$hero->name.'/icon.png')); ?>"></a>
                        </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?> 
        <div class="content-block">
                <h1 class="page-title">Create <span class="hero-name"><?php echo e($hero->name); ?></span> Build</h1>
                <?php echo Form::open(['action' => 'BuildsController@store', 'method' => 'POST']); ?>

                        <div class="form-group">
                                
                                <?php echo e(Form::label('title', 'Title')); ?>

                                <?php echo e(Form::text('title', '', ['class' => 'form-control', 'placeholder' => 'Title'])); ?>

                        </div>
                        <div class="form-group battlerites">
                                <label>Battlerites</label>
                                
                                <?php $lastHotkey = null; ?>
                                <?php $__currentLoopData = $battlerites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $battlerite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($lastHotkey != $battlerite->hotkey): ?>
                                        <div style="clear:both;"></div>
                                <?php endif; ?>
                                <?php echo e(Form::checkbox('build[]', $battlerite->name, null, ['id' => $battlerite->name])); ?>

                                <label for="<?php echo e($battlerite->name); ?>">
                                        <img src="<?php echo e(asset('images/'.$hero->name.'/abilities/'.$battlerite->hotkey.'.png')); ?>" class="skill-img <?php echo e($battlerite->hotkey); ?> <?php echo e(strtolower($battlerite->category)); ?>" alt="<?php echo e($hero->name); ?> Battlerite - <?php echo e($battlerite->name); ?>">
                                        <div class="tooltip">
                                                <h3><?php echo e($battlerite->name); ?></h3>
                                                <p><?php echo e($battlerite->description); ?></p>
                                        </div>
                                </label>
                                        <?php $lastHotkey = $battlerite->hotkey; ?>
                                       
             
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="form-group">
                                <?php echo e(Form::label('body', 'Body')); ?>

                                <?php echo e(Form::textarea('body', '', ['class' => 'form-control', 'id' => 'article-ckeditor', 'placeholder' => 'Body Text'])); ?>

                        </div>
                                <?php echo e(Form::text('hero_id', $hero->id, ['class' => 'hidden'])); ?>

                        <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

                <?php echo Form::close(); ?>

        </div>
        <?php endif; ?>
</div>

<script type="text/javascript">
var $checkboxes = $('input[type=checkbox]');

$checkboxes.change(function () {
    if (this.checked) {
        if ($checkboxes.filter(':checked').length == 5) {
            $checkboxes.not(':checked').prop('disabled', true);
        }
    } else {
        $checkboxes.prop('disabled', false);
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>