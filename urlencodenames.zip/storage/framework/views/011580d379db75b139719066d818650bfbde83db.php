<?php
use App\Hero;
use App\User;
use App\Auth;
use App\Build;
use App\Stream;
?>
<div class="sidebar-item rank-lookup">

        <div class="form-group">
            <?php echo e(Form::label('playerName', 'Player Rank Lookup')); ?>

            <?php echo e(Form::text('playerName', '', ['class' => 'form-control', 'placeholder' => 'Player Name'])); ?>

        </div>
        <?php echo e(Form::button('Search', ['class' => 'btn btn-primary', 'onclick' => 'lookupRedirect()'])); ?>


</div>

<?php echo $__env->yieldContent('sidebar'); ?>

<!--<div class="sidebar-item popular-builds">
    <h3 class="sidebar-title">Popular Builds</h3>
    <?php 
    $builds = Build::orderBy('views', 'desc')->paginate(5);
    ?>
    <?php if(count($builds) > 0): ?> 
        <?php $__currentLoopData = $builds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $build): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $selectedBattlerites = explode(', ', $build->build, 5);
            $hero = Hero::where('id', $build->hero_id)->firstOrFail();
            if($build->user_id != 0) {
                $user = User::where('id', $build->user_id)->firstOrFail();
                $username = $user->name;
            } else {
                $username = 'Anonymous';
            }
        ?>
            <div class="build-row">
                <div class="build-content">
                    <div class="build-image">
                            <a href="/builds/view/<?php echo e($build->id); ?>-<?php echo e($build->slug); ?>">
                                <img src="<?php echo e(asset('images/'.$hero->name.'/icon.png')); ?>">
                            </a>
                    </div>
                    <div class="build-desc">
                        <h3><a href="/builds/view/<?php echo e($build->id); ?>-<?php echo e($build->slug); ?>"><?php echo e($build->title); ?></a></h3>
                        <small>Build by <?php echo e($username); ?> on <?php echo e($build->created_at); ?></small>
                        <small>Views: <?php echo e($build->views); ?></small>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    <?php else: ?>
        <p>No builds Found</p>
    <?php endif; ?>
</div> -->

<div class="sidebar-item active-streams">
    <h3 class="sidebar-title">Featured Streams</h3>
    <?php $streams = Stream::orderBy('updated_at', 'desc')->take(5)->get();  ?>

    <?php $__currentLoopData = $streams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stream): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="stream">
            <a href="http://twitch.tv/<?php echo e($stream['username']); ?>" class="bold"><?php echo e($stream['title']); ?></a>
            <p><?php echo e($stream['username']); ?> - <?php echo e($stream['viewers']); ?> viewers</p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<script type="text/javascript">
    function lookupRedirect() {
    window.location.href ="http://battlerites.net/player/" + $('#playerName').val();
}
</script>