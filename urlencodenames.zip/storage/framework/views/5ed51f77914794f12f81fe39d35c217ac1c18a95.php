<?php
use App\Hero;
use App\User;
use App\Auth;
$heroes = Hero::all();
if(isset($hero)) {
    $heroName = $hero->name;
    $description = $heroName. ' builds for battlerite. Learn the optimal way to play '.$heroName.' to climb the leaderboards and improve your ranking.';
} else {
    $heroName = '';
    $description = 'Builds for battlerite. Learn the optimal way to play characters to climb the leaderboards and improve your ranking.';
}
?>
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('description', $description); ?>
<?php $__env->startSection('content'); ?>
        <div class="content-block">
            <h2 class="page-title">Filter by Hero</h2>
            <div class="filter-list">
            <?php $__currentLoopData = $heroes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <div class="hero-img">
                    <a href="/builds/<?php echo e($hero->name); ?>"><img src="<?php echo e(asset('images/'.$hero->name.'/icon.png')); ?>"></a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <div class="content-block">
        <h1 class="page-title">Builds</h1>
        <?php if(count($builds) > 0): ?> 
            <div class="builds-box">
                <?php $__currentLoopData = $builds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $build): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $selectedBattlerites = explode(', ', $build->build, 5);
                    $hero = Hero::where('id', $build->hero_id)->firstOrFail();
                    if($build->user_id != 0) {
                        $user = User::where('id', $build->user_id)->firstOrFail();
                        $username = $user->name;
                    } else {
                        $username = 'Anonymous';
                    }
                ?>
                    <div class="build-row">
                        <div class="build-content">
                            <div class="build-image">
                                    <a href="/builds/view/<?php echo e($build->id); ?>-<?php echo e($build->slug); ?>">
                                        <img src="<?php echo e(asset('images/'.$hero->name.'/icon.png')); ?>">
                                    </a>
                            </div>
                            <div class="build-desc">
                                <h3><a href="/builds/view/<?php echo e($build->id); ?>-<?php echo e($build->slug); ?>"><?php echo e($build->title); ?></a></h3>
                                <small>Build by <?php echo e($username); ?> on <?php echo e(date("m-d-Y", strtotime($build->created_at))); ?></small>
                                <small><?php echo e($build->build); ?></small>
                                <small><?php if($build->featured == 1) { echo '<span class="primary">FEATURED</span> | '; } ?>Views: <?php echo e($build->views); ?> | Score <?php echo e($build->score); ?></small>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
                <?php echo e($builds->links()); ?>

            </div>
        </div>
            <?php else: ?>
                <p>No builds Found. <a href="/builds/create/<?php echo e($heroName); ?>">Would you like to create one?</a></p>
        </div>
            <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>